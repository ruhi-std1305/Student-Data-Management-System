#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
using namespace std;


// Function for login screen
bool login() {
    string username, password;
    const string correctUsername = "admin";
    const string correctPassword = "admin123";

      cout<<"\t\t\t\t\t*************************************************\n";
   cout<<"\t\t\t\t\t*                                               *\n";
    cout<<"\t\t\t\t\t*       -----------------------------           *\n";
    cout<<"\t\t\t\t\t*          STUDENT DATA MANAGEMENT              *\n";
    cout<<"\t\t\t\t\t*       -----------------------------           *\n";
    cout<<"\t\t\t\t\t*                                               *\n";
   cout<<"\t\t\t\t\t*                                               *\n";
    cout<<"\t\t\t\t\t*                                               *\n";
    cout<<"\t\t\t\t\t*             Brought To You By                 *\n";
    cout<<"\t\t\t\t\t*         1.Asliraf Samaylan                    *\n";
    cout<<"\t\t\t\t\t*         2.Suraia Tabassoom Ruhi               *\n";
    cout<<"\t\t\t\t\t*         3.Sumaia Tarannoom Mahi               *\n";
   cout<<"\t\t\t\t\t*                                               *\n";
    cout<<"\t\t\t\t\t*************************************************\n\n\n";


    cout << "\n";
    cout<<endl;
    cout << "    -------------------------------     \n";
    cout<<"              LOGIN                        \n ";
    cout << "   -------------------------------     \n";
    cout<<endl;
    cout << "\n";

    cout << "ENTER USERNAME: ";
    cin >> username;
    cout << "ENTER PASSWORD: ";
    cin >> password;

    if (username == correctUsername && password == correctPassword) {
        cout << "\n";
         cout<<endl;
        cout << "WELCOME !!!! LOGIN IS SUCCESSFUL\n";
         cout<<endl;
        cout << "\n";
        return true;
    } else {
        cout << "\n";
        cout << "INVALID CREDENTIALS. PLEASE TRY AGAIN.\n";
        cout << "\n";
        return false;
    }
}

// Structure to represent a Student
struct Student {
    string id;
    string name;
    int age;
    float cgpa;
    string major;
    Student* next;
};

// Linked list class for managing students within a major
class MajorLinkedList {
private:
    Student* head;

public:
    MajorLinkedList() : head(nullptr) {}

    void addStudent(const string& id, const string& name, int age, float cgpa, const string& major) {
        Student* newStudent = new Student{id, name, age, cgpa, major, nullptr};
        if (!head) {
            head = newStudent;
        } else {
            Student* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newStudent;
        }
        cout << "Student added successfully to " << major << " major!\n";
    }

    void displayStudents() const {
        if (!head) {
            cout << "No students to display in this major.\n";
            return;
        }
        cout << "\n| " << setw(10) << "ID"
             << " | " << setw(20) << "Name"
             << " | " << setw(5) << "Age"
             << " | " << setw(5) << "CGPA"
             << " | " << setw(10) << "Major"
             << " |\n";
        cout << string(65, '-') << '\n';

        Student* temp = head;
        while (temp) {
            cout << "| " << setw(10) << temp->id
                 << " | " << setw(20) << temp->name
                 << " | " << setw(5) << temp->age
                 << " | " << setw(5) << fixed << setprecision(2) << temp->cgpa
                 << " | " << setw(10) << temp->major
                 << " |\n";
            temp = temp->next;
        }
    }

    void searchStudent(const string& id) {
        Student* temp = head;
        while (temp) {
            if (temp->id == id) {
                cout << "\nStudent Found!\n";
                cout << "| " << setw(10) << temp->id
                     << " | " << setw(20) << temp->name
                     << " | " << setw(5) << temp->age
                     << " | " << setw(5) << fixed << setprecision(2) << temp->cgpa
                     << " | " << setw(10) << temp->major
                     << " |\n";
                return;
            }
            temp = temp->next;
        }
        cout << "Student not found with ID: " << id << endl;
    }

   void updateStudent(const string& id) {
    Student* temp = head;
    while (temp) {
        if (temp->id == id) {
            cout << "\nEnter New Name: ";
            cin.ignore();
            getline(cin, temp->name);
            cout << "Enter New Age: ";
            cin >> temp->age;
            cout << "Enter New CGPA: ";
            cin >> temp->cgpa;

            cout << "\nStudent information updated successfully:\n";
            cout << "| " << setw(10) << temp->id
                 << " | " << setw(20) << temp->name
                 << " | " << setw(5) << temp->age
                 << " | " << setw(5) << fixed << setprecision(2) << temp->cgpa
                 << " | " << setw(10) << temp->major
                 << " |\n";
            return;
        }
        temp = temp->next;
    }
    cout << "Student not found with ID: " << id << endl;
}

    void deleteStudent(const string& id) {
        Student* temp = head;
        Student* prev = nullptr;
        if (temp && temp->id == id) {
            head = temp->next;
            delete temp;
            cout << "Student deleted successfully.\n";
            return;
        }

        while (temp && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }

        if (!temp) {
            cout << "Student not found with ID: " << id << endl;
            return;
        }

        prev->next = temp->next;
        delete temp;
        cout << "Student deleted successfully.\n";
    }

    ~MajorLinkedList() {
        while (head) {
            Student* toDelete = head;
            head = head->next;
            delete toDelete;
        }
    }
};

// Class to manage courses for a major
class CourseManager {
private:
    vector<string> courses;

public:
    void addCourse(const string& course) {
        courses.push_back(course);
    }

    void displayCourses() const {
        if (courses.empty()) {
            cout << "No courses available for this major.\n";
            return;
        }

        cout << "\n--- Available Courses ---\n";
        cout << "| " << setw(5) << "No."
             << " | " << setw(30) << "Course Name"
             << " |\n";
        cout << string(40, '-') << '\n';
        for (size_t i = 0; i < courses.size(); ++i) {
            cout << "| " << setw(5) << i + 1
                 << " | " << setw(30) << courses[i]
                 << " |\n";
        }
    }
};

// Main program
int main() {
    login();
    MajorLinkedList CSE, EEE, CCE, Others;
    CourseManager cseCourses, eeeCourses, cceCourses, otherCourses;

    // Predefined courses
    cseCourses.addCourse("Data Structures and Algorithms");
    cseCourses.addCourse("Mathematics");
    cseCourses.addCourse("Physics");
    cseCourses.addCourse("Computer Programming 1");
    cseCourses.addCourse("Digital Logic Design");

    eeeCourses.addCourse("Circuits and Systems");
    eeeCourses.addCourse("Electromagnetics");
    eeeCourses.addCourse("Power Systems");
    eeeCourses.addCourse("Control Systems");

    cceCourses.addCourse("Wireless Communication");
    cceCourses.addCourse("Digital Signal Processing");
    cceCourses.addCourse("Data Networks");
    cceCourses.addCourse("Embedded Systems");

    otherCourses.addCourse("Basic English");
    otherCourses.addCourse("Introduction to Psychology");
    otherCourses.addCourse("Environmental Science");

    int choice;
    do {
        cout << "\n--- Student and Course Management System ---\n";
        cout << "1. Add Student\n";
        cout << "2. Display All Students Information\n";
        cout << "3. Available Courses\n";
        cout << "4. Search Student\n";
        cout << "5. Update Student\n";
        cout << "6. Delete Student\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            string id, name, major;
            int age;
            float cgpa;

            cout << "Enter Student Roll Number: ";
            cin >> id;
            cout << "Enter Student Name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter Student Age: ";
            cin >> age;
            cout << "Enter Student CGPA: ";
            cin >> cgpa;

            // Determine the major based on roll number
            if (id.find("CE") != string::npos) {
                CCE.addStudent(id, name, age, cgpa, "CCE");
            } else if (id.find("C") != string::npos) {
                CSE.addStudent(id, name, age, cgpa, "CSE");
            } else if (id.find("E") != string::npos) {
                EEE.addStudent(id, name, age, cgpa, "EEE");
            } else {
                Others.addStudent(id, name, age, cgpa, "Others");
            }
            break;
        }
        case 2: {
            cout << "\n--- All Students Information ---\n";
            cout << "CSE Students:\n";
            CSE.displayStudents();
            cout << "EEE Students:\n";
            EEE.displayStudents();
            cout << "CCE Students:\n";
            CCE.displayStudents();
            cout << "Other Students:\n";
            Others.displayStudents();
            break;
        }
        case 3: {
            cout << "\n--- Available Courses ---\n";
            cout << "1. CSE\n";
            cout << "2. EEE\n";
            cout << "3. CCE\n";
            cout << "4. Others\n";
            cout << "Enter your choice: ";
            int courseChoice;
            cin >> courseChoice;

            switch (courseChoice) {
            case 1:
                cseCourses.displayCourses();
                break;
            case 2:
                eeeCourses.displayCourses();
                break;
            case 3:
                cceCourses.displayCourses();
                break;
            case 4:
                otherCourses.displayCourses();
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
            }
            break;
        }
        case 4: {
            cout << "Enter Student ID to search: ";
            string id;
            cin >> id;
            if (id.find("CE") != string::npos) {
                CCE.searchStudent(id);
            } else if (id.find("C") != string::npos) {
                CSE.searchStudent(id);
            } else if (id.find("E") != string::npos) {
                EEE.searchStudent(id);
            } else {
                Others.searchStudent(id);
            }
            break;
        }
        case 5: {
            cout << "Enter Student ID to update: ";
            string id;
            cin >> id;
            if (id.find("CE") != string::npos) {
                CCE.updateStudent(id);
            } else if (id.find("C") != string::npos) {
                CSE.updateStudent(id);
            } else if (id.find("E") != string::npos) {
                EEE.updateStudent(id);
            } else {
                Others.updateStudent(id);
            }
            break;
        }
        case 6: {
            cout << "Enter Student ID to delete: ";
            string id;
            cin >> id;
            if (id.find("CE") != string::npos) {
                CCE.deleteStudent(id);
            } else if (id.find("C") != string::npos) {
                CSE.deleteStudent(id);
            } else if (id.find("E") != string::npos) {
                EEE.deleteStudent(id);
            } else {
                Others.deleteStudent(id);
            }
            break;
        }
        case 7:
            cout << "Exiting the program...\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 7);

    return 0;
}
